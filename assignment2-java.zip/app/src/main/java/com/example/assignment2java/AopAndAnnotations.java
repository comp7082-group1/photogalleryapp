//package com.example.assignment2java;
//
//import org.aspectj.lang.JoinPoint;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Before;
////import org.springframework.boot.autoconfigure.SpringBootApplication
////import org.springframework.boot.runApplication
////import org.springframework.stereotype.Component
////import org.springframework.web.bind.annotation.GetMapping
////import org.springframework.web.bind.annotation.RestController
//import java.lang.annotation.Retention;
//import java.lang.annotation.Target;
//import java.util.*;


//@SpringBootApplication
//class KubeTestApplication
//
//fun main(args: Array<String>) {
//    runApplication<KubeTestApplication>(*args)
//}

//
//@RestController
//class HelloWorldController {
//
//    @GetMapping("/hello")
//    @TestMe(roles = ["ppp","qqq"])
//    fun helloWorld(): String {
//        return "Hello World from Kube Kotlin ${Date()}()"
//    }
//
//}
//
//@Target(AnnotationTarget.FUNCTION)
//@Retention(AnnotationRetention.RUNTIME)
//annotation class TestMe()
//
//@Aspect
//class ExampleAspect {
//
//    @Before("@annotation(TestMe)")
//    fun before(joinPoint: JoinPoint) {
//
//        true
////        val method = joinPoint.target.javaClass.getMethod(joinPoint.signature.name)
////        val x = method.getAnnotation(TestMe::class.java)
////        x.roles.forEach { println(it) }
////        println(" Check for user access " )
////        println(" Allowed execution for {} $joinPoint")
//    }
//
//}