package com.example.assignment2java.show_photo;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

public class ShowPhotoViewModel extends AndroidViewModel {
    public ShowPhotoViewModel(@NonNull Application application) {
        super(application);
    }
}
