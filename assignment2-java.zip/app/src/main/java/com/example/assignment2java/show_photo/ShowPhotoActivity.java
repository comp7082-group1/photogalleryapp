package com.example.assignment2java.show_photo;

import androidx.appcompat.app.AppCompatActivity;

public class ShowPhotoActivity extends AppCompatActivity {
}
